#!/bin/bash
#SBATCH -J b
#SBATCH -N 2
#SBATCH -n 64
#SBATCH -t 120000:00:00
#SBATCH -p fat
#SBATCH --mem=220G
#SBATCH --exclusive


#Print the system information and Enter the workdirectory
WORKDIR=/public/home/zzumpc11/bionet/bionet
source /public/home/zzumpc11/ADT/autodock_vina_1_2_3_linux_x86/vina

for f in bionet*.pdbqt; do
    b=`basename $f .pdbqt`
    echo Processing ligand $b
    mkdir -p $b
   srun --mpi=pmix_v3 --ntasks=1 /public/home/zzumpc11/ADT/autodock_vina_1_2_3_linux_x86/vina --config config.txt --ligand $f --out ${b}/out.pdbqt >log_file/${b}_log.txt
done


echo `date`

~

