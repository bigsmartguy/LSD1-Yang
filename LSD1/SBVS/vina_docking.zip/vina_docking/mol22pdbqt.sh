source /public/home/zzumpc11/ADT/mgltools_env
for i in {1..26}
do      pythonsh /public/home/zzumpc11/ADT/mgltools/MGLToolsPckgs/AutoDockTools/Utilities24/prepare_ligand4.py  -l bionet$i.mol2 -o bionet$i.pdbqt
	echo $i
done
